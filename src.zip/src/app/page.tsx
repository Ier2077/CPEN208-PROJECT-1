

export default function Home() {
  return <h1 className="text-4xl ">Home</h1>;
    

}
