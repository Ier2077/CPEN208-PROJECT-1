import SigninForm from "@/components/form/SigninForm";

const page =()=> {
    return (
        <div className="w-full">
           <SigninForm />
        </div>
    );
};

export default page;