import SignupForm from "@/components/form/SignupForm";

const page =()=> {
    return (
        <div className="w-full">
           <SignupForm />
        </div>
    );
};

export default page;