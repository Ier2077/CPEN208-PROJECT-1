import SideNavbar from "@/components/SideNavbar";
import styles from './admin.module.css'
const page = () => {
  return (
    <><div className="text-4xl">
      Admin page - Welcome back
    </div>
    <div className="text-2xl">How're you today?</div>

    <div className={styles.sidenavbar}>
        <SideNavbar></SideNavbar>
      </div></>
  )
}

export default page;