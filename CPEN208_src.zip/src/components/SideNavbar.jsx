const SideNavbar = () =>{
    return 
        <div className="flex-none w-20 bg-gray-200 h-screen">01</div>;
    
};

export default SideNavbar;